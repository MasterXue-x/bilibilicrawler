#--author:Master Xue
import requests
from bs4 import BeautifulSoup
class bilibili:
    def __init__(self):
        self.URL = "https://search.bilibili.com/all?keyword=%E5%8D%81%E6%9C%88%E6%96%B0%E7%95%AA&from_source=nav_suggest_new&page="
        self.startnum = []
        for start_num in range(1,2):
            self.startnum.append(start_num)
        self.header = {"user-agent":'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36'}
    def get_bilibili(self):
        Name=[]
        playnum=[]
        dianzan=[]
        toubi=[]
        shoucang=[]
        for start in self.startnum:
            web2=[]
            start = str(start)
            html = requests.get(self.URL, params={'start' : start })
            soup = BeautifulSoup(html.text, 'html.parser')
            name = soup.select('#all-list > div.flow-loader > div.mixin-list > ul > li > div > div.headline.clearfix > a ')
            for name in name:
                Name.append(name)
                web2.append(name['href'])
            for web in web2:
                html2 = requests.get('https:'+web, params={'start' : start })
                soup2 = BeautifulSoup(html2.text, 'html.parser')
                dianzan = soup2.select('#arc_toolbar_report > div.ops > span.like')
                toubi = soup2.select('#arc_toolbar_report > div.ops > span.coin')
                shoucang = soup2.select('#arc_toolbar_report > div.ops > span.collect')
                for dianzan in dianzan:
                    dz=dianzan.get_text()
                    dianzan.append(dz.replace('\n',''))
                for toubi in toubi:
                    tb=toubi.get_text()
                    tob=tb.replace('\n','')
                    tobi=tob.replace(' ','')
                for shoucang in shoucang:
                    sc=shoucang.get_text()
                    #shc=sc.replace('\n','')
                    print(sc)
#if __name__ == '__main__':
cls = bilibili()
cls.get_bilibili()
