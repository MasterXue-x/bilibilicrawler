#--author:Master Xue
import requests
from bs4 import BeautifulSoup
import openpyxl
def getbilibili():
    Name = []
    playnum = []
    dianzan = []
    toubi = []
    shoucang = []
    zhuanfa = []
    startnum = []
    URL = "https://search.bilibili.com/all?keyword=%E9%AC%BC%E7%81%AD%E4%B9%8B%E5%88%83"
    headers = {"user-agent":'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36',
       "Cookie":"_uuid=68113808-D54B-E202-BA08-1373B3D60F9974461infoc; buvid3=A258B2C8-BE88-463E-B523-1E23B53D3F6C155809infoc; rpdid=|(k|~|mYkY|u0J'ulm|RlRRkR; PVID=1; sid=j2jnbsb2; DedeUserID=481573872; DedeUserID__ckMd5=7625a147c93ab815; SESSDATA=896b94cc%2C1608437395%2Cf735e*61; bili_jct=734e80e13ef61ab7b733d35f61453696; finger=1295565314; arrange=matrix; CURRENT_FNVAL=80; blackside_state=1"}
    web2 = []
###第一页单独抓取
    html = requests.get(URL, params={'page': 1}, headers=headers)
    html.encoding = 'utf-8'
    soup = BeautifulSoup(html.text, 'lxml')
    # 获取名称和视频网页
    name = soup.select('#all-list > div.flow-loader > div.mixin-list > ul.video-list.clearfix > li > div > div.headline.clearfix > a')
    for name in name:
        Name.append(
            name.get_text())
        web2.append(name['href'])
    # 获取播放量
    play_num = soup.select('#all-list > div.flow-loader > div.mixin-list > ul.video-list.clearfix > li > div > div.tags > span.so-icon.watch-num')
    for play_num in play_num:
        pn = play_num.get_text()
        pl = pn.replace('\n', '')
        pln = pl.replace(' ', '')
        playnum.append(pln)
    # 获取点赞、投币、收藏
    for web2 in web2:
        html2 = requests.get('https:' + web2, headers=headers)
        html2.encoding = 'utf-8'
        soup2 = BeautifulSoup(html2.text, 'lxml')
        dianzan1 = soup2.select('#arc_toolbar_report > div.ops > span.like')
        toubi1 = soup2.select('#arc_toolbar_report > div.ops > span.coin ')
        shoucang1 = soup2.select('#arc_toolbar_report > div.ops > span.collect')
        zhuanfa1 = soup2.select('#arc_toolbar_report > div.ops > span.share')
        if dianzan1:
            for dianzan1 in dianzan1:
                dz = dianzan1.get_text()
                dz2 = dz.replace(' ', '')
                dianzan.append(dz2.replace('\n', ''))
        else:
            dianzan.append('error')
        if toubi1:
            for toubi1 in toubi1:
                tb = toubi1.get_text()
                tob = tb.replace('\n', '')
                tobi = tob.replace(' ', '')
                toubi.append(tobi)
        else:
            toubi.append('error')
        if shoucang1:
            for shoucang1 in shoucang1:
                sc = shoucang1.get_text()
                shc = sc.replace('\n', '')
                schn = shc.replace(' ', '')
                shoucang.append(schn)
        else:
            shoucang.append('error')
        if zhuanfa1:
            for zhuanfa1 in zhuanfa1:
                zf = zhuanfa1.get_text()
                zhf = zf.replace('\n', '')
                zhuan = zhf.replace(' ', '')
                zhuanfa.append(zhuan)
        else:
            zhuanfa.append('error')
###抓取其余页
    for i in range(2, 11):
        startnum.append(i)
    for startnum in startnum:
        web2 = []
        #url = URL+str(i)
        html = requests.get(URL, params={'page': startnum}, headers=headers)
        html.encoding = 'utf-8'
        soup = BeautifulSoup(html.text, 'lxml')
        #获取名称和视频网页
        name = soup.select('#all-list > div.flow-loader > ul > li > div > div.headline.clearfix > a')
        for name in name:
            Name.append(name.get_text())
            web2.append(name['href'])
        #获取播放量
        play_num = soup.select('#all-list > div.flow-loader > ul > li > div > div.tags > span.so-icon.watch-num')
        for play_num in play_num:
            pn=play_num.get_text()
            pl=pn.replace('\n','')
            pln=pl.replace(' ','')
            playnum.append(pln)
        #获取点赞、投币、收藏
        for web2 in web2:
            html2 = requests.get('https:'+web2, headers=headers)
            html2.encoding = 'utf-8'
            soup2 = BeautifulSoup(html2.text, 'lxml')
            dianzan1 = soup2.select('#arc_toolbar_report > div.ops > span.like')
            toubi1 = soup2.select('#arc_toolbar_report > div.ops > span.coin ')
            shoucang1 = soup2.select('#arc_toolbar_report > div.ops > span.collect')
            zhuanfa1 = soup2.select('#arc_toolbar_report > div.ops > span.share')
            if dianzan1:
                for dianzan1 in dianzan1:
                    dz = dianzan1.get_text()
                    dz2 = dz.replace(' ','')
                    dianzan.append(dz2.replace('\n', ''))
            else:
                dianzan.append('error')
            if toubi1:
                for toubi1 in toubi1:
                    tb = toubi1.get_text()
                    tob = tb.replace('\n', '')
                    tobi = tob.replace(' ', '')
                    toubi.append(tobi)
            else:
                toubi.append('error')
            if shoucang1:
                for shoucang1 in shoucang1:
                    sc = shoucang1.get_text()
                    shc=sc.replace('\n', '')
                    schn = shc.replace(' ', '')
                    shoucang.append(schn)
            else:
                shoucang.append('error')
            if zhuanfa1:
                for zhuanfa1 in zhuanfa1:
                    zf = zhuanfa1.get_text()
                    zhf = zf.replace('\n', '')
                    zhuan = zhf.replace(' ', '')
                    zhuanfa.append(zhuan)
            else:
                zhuanfa.append('error')

    return(Name, playnum, dianzan, toubi, shoucang, zhuanfa)
(Name,playnum,diz,tobi,shca,zf)=getbilibili()
#编写exel
wb = openpyxl.load_workbook('pachong.xlsx')
wb.create_sheet('鬼灭之刃',2)
sheet = wb.worksheets[2]
sheet['A1'].value = '名称'
sheet['B1'].value = '播放量'
sheet['C1'].value = '点赞'
sheet['D1'].value = '投币'
sheet['E1'].value = '收藏'
sheet['F1'].value = '转发'
for i in range(1, len(Name)+1):
    sheet['A'+str(i+1)].value = Name[i-1]
    sheet.row_dimensions[i].height = 15
for k in range(1, len(playnum)+1):
    sheet['B'+str(k+1)].value = playnum[k-1]
for j in range(1, len(diz)+1):
    sheet['C'+str(j+1)].value = diz[j-1]
for l in range(1, len(tobi)+1):
    sheet['D'+str(l+1)].value = tobi[l-1]
for s in range(1, len(shca)+1):
    sheet['E'+str(s+1)].value = shca[s-1]
for h in range(1, len(zf)+1):
    sheet['F'+str(h+1)].value = zf[h-1]
wb.save('pachong.xlsx')