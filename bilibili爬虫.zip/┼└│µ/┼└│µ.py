#--author:Master Xue
import requests
from bs4 import BeautifulSoup
import openpyxl
class bilibili:
    def __init__(self):
        self.URL = "https://search.bilibili.com/all?keyword=%E5%8D%81%E6%9C%88%E6%96%B0%E7%95%AA&from_source=nav_suggest_new&page="
        self.startnum = []
        for start_num in range(1, 11):
            self.startnum.append(start_num)
        self.header = {"user-agent":'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36'}
    def get_bilibili(self):
        title = []
        play_num = []
        for start in self.startnum:
            start = str(start)
            html = requests.get(self.URL, params={ 'start' : start}  )
            soup = BeautifulSoup(html.text, 'html.parser')
            name = soup.select( '#all-list > div.flow-loader > div.mixin-list > ul > li > div > div.headline.clearfix > a' )
            playnum = soup.select('#all-list > div.flow-loader > div.mixin-list > ul > li > div > div.tags > span.so-icon.watch-num')
            for name in name:
                title.append(name.get_text())
            for a in playnum:
                b = a.get_text()
                b = b.replace('\n','')
                b = b.replace(' ','')
                play_num.append(b)
        return (title,play_num)

(title,playnum) = bilibili().get_bilibili()
#print(title)
wb = openpyxl.load_workbook('pachong.xlsx')
#wb.create_sheet('十月新番',0)
sheet = wb.worksheets[0]
sheet['A1'].value = '名称'
sheet['B1'].value = '播放量'
for i in range(1, len(title)+1):
    sheet['A'+str(i+1)].value = title[i-1]
    sheet.row_dimensions[i].height = 15
for k in range(1, len(playnum)+1):
    sheet['B'+str(k+1)].value = playnum[k-1]

wb.save('pachong.xlsx')
